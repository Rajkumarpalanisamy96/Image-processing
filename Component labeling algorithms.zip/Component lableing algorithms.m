A = [ 1 1 0 0 0 0 0;  1 1 0 0 1 1 0;  1 1 0 0 0 1 0; 1 1 0 0 0 0 0;  0 0 0 0 0 1 0; 0 0 0 0 0 0 0]
I = false(size(A));
[rows,cols] = size(A);
B = zeros(rows,cols);
number = 1;
for row = 1 : rows
    for col = 1 : cols
        if A(row,col) == 0
            I(row,col) = true;
        elseif I(row,col)
            continue;
        else
            C = [row col];
            while ~isempty(C) 
                loc = C(1,:);
                C(1,:) = [];
                if I(loc(1),loc(2))
                    continue;
                end
                I(loc(1),loc(2)) = true;
                B(loc(1),loc(2)) = number;
                [y,x] = meshgrid(loc(2)-1:loc(2)+1, loc(1)-1:loc(1)+1);
                y = y(:);
                x = x(:);
                out = x < 1 | x > rows | y < 1 | y > cols;%// for out of boundary locatins
                y(out) = [];
                x(out) = [];
                Io = I(sub2ind([rows cols], x,y));%// not to revisit previous locations
                y(Io) = [];
                x(Io) = [];
                zero = A(sub2ind([rows cols], x,y));%// for location that have value as Zero
                y(~zero) = [];
                x(~zero) = [];
                C = [C; [x y]];
            end
            number = number + 1;
        end
    end
end   

 